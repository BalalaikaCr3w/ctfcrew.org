# -*- coding: utf-8 -*-

import base64
import SocketServer
import sys
import mitmlib

class ServerHandler(SocketServer.BaseRequestHandler):

    def fail(self, message):
        self.request.sendall(message + "\nGood-bye.\n")
        self.request.close()
        return False

    def captcha(self):
        proof = base64.b64encode(os.urandom(9))
        self.request.sendall(proof)
        test = self.request.recv(20)
        ha = hashlib.sha1()
        ha.update(test)
        if test[0:12]!=proof or not ha.digest().endswith('\xFF\xFF\xFF'):
            return False
        else:
            return True

    def handle(self):
        #if not self.captcha():
            #return self.fail("You're a robot!")
        if not (self.request.recv(50) == "アリスです"):
            return self.fail("You're not Alice!")
        self.request.sendall("千佐だよ")

        secretshare2, publicshare2 = mitmlib.mkshare()

        got = self.request.recv(2048).split(',')
        publicshare1 = tuple([int(got[0]), int(got[1])])

        to_send = str(publicshare2[0]) + "," + str(publicshare2[1])
        self.request.sendall(to_send)
        aeskey = mitmlib.mksecret(secretshare2, publicshare1)

        slices = zip(CHECK[0::2], CHECK[1::2])
        for a, b in slices:
            if a != mitmlib.decrypt(aeskey, self.request.recv(400)):
                self.fail("That's wrong!")
            self.request.sendall(mitmlib.encrypt(aeskey, b))

        print mitmlib.decrypt(aeskey, self.request.recv(400))
        self.request.sendall(mitmlib.encrypt(aeskey, "FLAG PART TWO: {" + KEY + "}\n"))

        self.request.recv(100)
        self.request.sendall(mitmlib.encrypt(aeskey, "じゃ!"))
        self.request.close()


class ThreadedServer(SocketServer.ThreadingMixIn, SocketServer.TCPServer):
    pass

KEY = ""
CHECK = ""

if __name__ == "__main__":
    HOST = sys.argv[1]
    PORT = int(sys.argv[2])

    KEY = open('chisa.txt', 'r').read()[:-1]
    CHECK = open('check.txt', 'r').read()[:-1]
    server = ThreadedServer((HOST, PORT), ServerHandler)
    server.allow_reuse_address = True
    server.serve_forever()


