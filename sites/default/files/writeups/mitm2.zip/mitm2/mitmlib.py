import curve25519, hashlib
from random import randrange
import base64
from Crypto import Random
from Crypto.Cipher import AES

BASE  = curve25519.point(9)
ORDER = 2**252 + 27742317777372353535851937790883648493

def mkshare():
    power = randrange(1, ORDER)
    point = curve25519.times(BASE, power)
    return (power, point)

def mksecret(secret, public):
    point = curve25519.times(public, secret)
    key = hashlib.sha256(repr(point)).digest()
    return key

def pad(s):
    bs = 32
    return s + (bs - len(s) % bs) * chr(bs - len(s) % bs)

def unpad(s):
    return s[:-ord(s[len(s)-1:])]

def encrypt(key, msg):
    msg = pad(msg)
    iv = Random.new().read(AES.block_size)
    cipher = AES.new(key, AES.MODE_CBC, iv)
    return base64.b64encode(iv + cipher.encrypt(msg))

def decrypt(key, enc):
    enc = base64.b64decode(enc)
    iv = enc[:16]
    cipher = AES.new(key, AES.MODE_CBC, iv)
    return unpad(cipher.decrypt(enc[16:]))
