# -*- coding: utf-8 -*-

import base64
import sys
import SocketServer
import mitmlib

class ServerHandler(SocketServer.BaseRequestHandler):

    def fail(self, message):
        self.request.sendall(message + "\nGood-bye.\n")
        self.request.close()
        return False

    def captcha(self):
        proof = base64.b64encode(os.urandom(9))
        self.request.sendall(proof)
        test = self.request.recv(20)
        ha = hashlib.sha1()
        ha.update(test)
        if test[0:12]!=proof or not ha.digest().endswith('\xFF\xFF\xFF'):
            return False
        else:
            return True

    def handle(self):
        #if not self.captcha():
            #return self.fail("You're a robot!")
        self.request.sendall("アリスです")
        if not (self.request.recv(50) == "千佐だよ"):
            return self.fail("You're not Chisa!")

        secretshare1, publicshare1 = mitmlib.mkshare()

	to_send = str(publicshare1[0]) + "," + str(publicshare1[1])
        self.request.sendall(to_send)

	got = self.request.recv(2048).split(',')
        publicshare2 = tuple([int(got[0]), int(got[1])])
        aeskey = mitmlib.mksecret(secretshare1, publicshare2)

        slices = zip(CHECK[0::2], CHECK[1::2])
        for a, b in slices:
            self.request.sendall(mitmlib.encrypt(aeskey, a))
            if b != mitmlib.decrypt(aeskey, self.request.recv(400)):
                self.fail("That's wrong!")

        self.request.sendall(mitmlib.encrypt(aeskey, "FLAG PART ONE: {" + KEY + "}\n"))
	print mitmlib.decrypt(aeskey, self.request.recv(400))

        self.request.sendall(mitmlib.encrypt(aeskey, "じゃ!"))
        self.request.recv(100)
        self.request.close()


class ThreadedServer(SocketServer.ThreadingMixIn, SocketServer.TCPServer):
    pass

KEY = ""
CHECK = ""

if __name__ == "__main__":
    HOST = sys.argv[1]
    PORT = int(sys.argv[2])

    KEY = open('arisu.txt', 'r').read()[:-1]
    CHECK = open('check.txt', 'r').read()[:-1]
    server = ThreadedServer((HOST, PORT), ServerHandler)
    server.allow_reuse_address = True
    server.serve_forever()


