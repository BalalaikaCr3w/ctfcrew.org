Input:
cacert.pem -- CA certificate
N1.pem, N2.pem, N3.pem -- User certificates

To do:
Make CA-issued certificate with CN=admin