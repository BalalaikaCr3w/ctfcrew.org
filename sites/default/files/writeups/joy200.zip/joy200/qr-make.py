import re
z = '''
01*       XX   X X X    X  XX       *
02* XXXXX XXX XX   XX X     X XXXXX *
03* X   X XXXX   X X XX XX  X X   X *
04* X   X XXXXXX  X X  XX XXX X   X *
05* X   X XXXXXX  XXX XX XXXX X   X *
06* XXXXX X  X X XX  X  X XXX XXXXX *
07*       X X X X X X X X X X       *
08*XXXXXXXXX  XX    XXX  X XXXXXXXXX*
09* XX X  X X  X  X XXXX X X X XXXXX*
10*X XX XX   XXX XX XXX X X    XX X *
11*X XXXX   XX X  XXXX  X X X    XX *
12*XXXX XXXX XXXXX XXXXX XXX  XX X  *
13* XXXX   XX  XX X  XXX XX    XXXX *
14*   XXXX  X  XX  XX X   XXX X XXX *
15*X  XXX XXX  X X   XXXXX  XX X   X*
16*      X  XX  X X    X  X  X XXX X*
17*X XXXX X     XX   X X X  X XX XXX*
18*XX    XX  X   XX XXXX X X XXXX   *
19*X XX     XX  X X   XXXXX X X XXXX*
20*   X XXXX X XX        XXX XXXXXXX*
21*   X   XX   XXX  XX X X   X X XX *
22* XX X X XX   X  X  XX  XXX XX    *
23*XXX XX   X XX  X XX XXXXXX XXX X *
24* X  X X XXX   X XX    X X X X X X*
25*X  X X X  XX XX       XX     XXXX*
26*XXXXXXXX    XX XX X  X X XXX XXX *
27*       XX XX   X  XXXX X X X XX X*
28* XXXXX X XXX XX   XXX XX XXX XXX *
29* X   X XXXX  X X  X    X     XXX *
30* X   X X XX XX X XXXX X  X    XXX*
31* X   X XX X    XX XXXXX XXX    X *
32* XXXXX XXX  X XXXX X   X XXX  XXX*
33*       X  X X   XXXX  XX X XX X X*
'''
html = '<!DOCTYPE html><html><head><style>.a{width: 330px;margin:10px;}.c{width:10px;height:10px;float:left;}.b{background:#000;}.w{background:#fff;}</style></head><body><div class="a">'
m = z.split("\n")
m = m[1:-1]
for x in m:
	z = re.findall("\*([X\s]+)\*", x)
	for c in z[0]:
		if c == ' ':
			html += '<div class="c b"></div>'
		else:
			html += '<div class="c w"></div>'
html += '</div></body></html>'
with open('1.html', 'w') as h:
	h.write(html)