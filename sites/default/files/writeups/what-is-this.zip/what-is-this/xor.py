#!/usr/bin/env python
# -*- coding: utf-8 -*-

from PIL import Image
w = 0
h = 0
edge = 100

def load (fn):
	global w, h
	im = Image.open(fn)
	w, h = im.size
	im = im.convert('RGB')
	pix = im.load()
	s = ''
	for y in xrange(h):
		for x in xrange(w):
			r, g, b = pix[x, y]
			s += str(+(r > edge))
	return s

pic1 = load('pic1.jpg')
pic2 = load('pic2.jpg')
pic = [int(x[0])^int(x[1]) for x in zip(pic1, pic2)]

im = Image.new('RGB', (w, h))
pix = im.load()
for y in xrange(h):
	for x in xrange(w):
		pix[x, y] = (0, 0, 0) if pic[y * w + x] == 0 else (255, 255, 255)
im.save('result.png')