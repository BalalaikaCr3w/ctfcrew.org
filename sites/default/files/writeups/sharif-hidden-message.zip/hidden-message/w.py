#!/usr/bin/env python
# -*- coding: utf-8 -*-

import re

with open('as_text.txt', 'r') as f:
	z = f.read()

m = re.findall('Src Port: (\d{4})', z)

s = ''.join([str(+(x == '3400')) for x in m])

r = ''
for i in xrange(0, len(s), 8):
	r += chr(int(s[i:i+8], 2))

print r