#!/usr/bin/python
data = open('client_app2.mem', 'rb').read()
data = data.replace(' ', '')
data = data.replace('\n', '')
data = data.decode('hex')
buf = ''
i = 0
while i + 1 < len(data):
	buf += data[i + 1]
	buf += data[i]
	i += 2
open('firm.bin', 'wb').write(buf)
